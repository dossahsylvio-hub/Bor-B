# 🇸🇳 Bor‑Bi Infrastructure – Version 1.1 (TransTech Secure)

## 1️⃣  Introduction
Cette version consolide l’environnement industriel de **Bor‑Bi**, la PWA panafricaine de
**TransTech Solution**, avec sauvegarde chiffrée GPG et déploiement automatisé Ansible.

---

## 2️⃣  Pré‑requis Système
- Ubuntu 20.04 LTS ou supérieur  
- Ports : 22 (SSH), 80 / 443 (HTTP/S)  
- Compte sudo pour l’administrateur TransTech  
- Accès à Internet (pour images Docker et dépendances)

---

## 3️⃣  Déploiement Docker Compose

### Étapes
```bash
git clone [git.trans-tech.africa](https://git.trans-tech.africa/borbi.git)
cd borbi
cp .env.example .env
nano .env     #  renseigner secrets JWT, DB, GPG, etc.

docker compose -f production.yaml up -d --build
